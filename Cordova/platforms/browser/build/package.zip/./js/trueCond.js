$(document).ready(function(){
  setTimeout(setCond, 500);
});

function setCond(){
  $('#help').html("Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quod veritatis reiciendis soluta dolorum cupiditate et, numquam dolorem tenetur explicabo maiores debitis, distinctio, eaque quas voluptatibus blanditiis voluptatum illo aperiam ipsum?");
}
